import { useEffect, useState } from "react"
import { render } from "react-dom";
import styled from "styled-components";
import { onGeo } from "../api";

const API_KEY = "e8bf3889f2eb88ab8fdd829542403f05";

interface IGeo {
    longitude: number;
    latitude: number;
}

const WeatherWrapper = styled.div`
    width: 100%;
    height: 100vh;
    font-size: 30px;
    text-align: center;
`

function Weather(position: any) {
    let latitude;
    let longitude;
    const [lat, setLat] = useState<number>();
    const [lon, setLon] = useState<number>();
    const [state, setState] = useState<any>();
    const geo = (position: any) => {
        latitude = position.coords.latitude;
        console.log(latitude);
        longitude = position.coords.longitude;
        console.log(longitude);
        const url = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${API_KEY}&units=metric`;
        fetch(url)
            .then((res) => res.json())
            .then((data) => {
                console.log(data.main.temp)
                setState(data)
            })
    }
    const error = () => {
        setState("error")
    }
    navigator.geolocation.getCurrentPosition(geo, error)
    return (
        <WeatherWrapper>
            {lat && <span>{lat}</span>}<br />
            {lon && <span>{lon}</span>}
            {state}
        </WeatherWrapper>
    )
}



// (position) => {
//     const lat = position.coords.latitude;
//     console.log(lat)
//     const lon = position.coords.longitude;
//     console.log(lon)
//     const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric`;
//     return fetch(url).then((res) => res.json())
// }



export default Weather;