import HeaderMain from "../components/HeaderMain";
import ModeBtn from "../components/ModeBtn";
import Weather from "../components/Weather";

function Home() {
    return (
        <>
            <HeaderMain />
            <ModeBtn />
        </>
    )
}

export default Home;